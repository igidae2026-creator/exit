from __future__ import annotations

import importlib
import json
import multiprocessing as mp
import hashlib

import os
import random
import shutil
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from .quest import ensure_quest, update_quest
from .replay_engine import replay_sample
from .shared_replay import sample_shared, publish_to_shared
from .swarm_policy import should_publish, cleanup_shared

try:
    import psutil  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    psutil = None


STRATEGY_KEYS = ("quality", "novelty", "diversity", "efficiency", "cost")

POPULATION_SIZE = 64
MIN_WORKERS = 1
CPU_COUNT = max(1, mp.cpu_count())
INITIAL_WORKERS = max(MIN_WORKERS, CPU_COUNT * 2)
MAX_WORKERS = max(MIN_WORKERS, CPU_COUNT * 4)
POOL_TASKS_PER_CHILD = 200

ARTIFACT_LIMIT = 5000
ARTIFACT_PURGE_COUNT = 2000
MUTATION_NOISE = 0.08
TICK_SLEEP_SECONDS = 1.0
LOG_ROTATE_BYTES = 50 * 1024 * 1024

APP_ROOT = Path(os.getenv("METAOS_APP_DIR", Path(__file__).resolve().parents[1]))
INSTANCE_DIR = Path(os.getenv("METAOS_INSTANCE_DIR", APP_ROOT / "state"))
SHARED_ARTIFACTS_DIR = Path(os.getenv("METAOS_SHARED_ARTIFACTS_DIR", APP_ROOT / "shared_artifacts"))
LOG_DIR = Path(os.getenv("METAOS_LOG_DIR", APP_ROOT / "logs"))

DOMAINS_DIR = APP_ROOT / "domains"
ARTIFACT_DIR = SHARED_ARTIFACTS_DIR
STATE_DIR = INSTANCE_DIR
CHECKPOINT_PATH = STATE_DIR / "checkpoint.json"
METRICS_PATH = LOG_DIR / "metrics.jsonl"
EVENTS_PATH = LOG_DIR / "events.jsonl"
LOG_ARCHIVE_DIR = LOG_DIR / "archive"
HEARTBEAT_PATH = STATE_DIR / "heartbeat"

_DOMAIN_GENERATE_CACHE: dict[str, Callable[[], Any] | None] = {}
_CURRENT_QUEST: dict[str, Any] | None = None
_LLM_GENERATOR: Callable[[str, dict[str, Any]], Any] | None = None
_LLM_RESOLVED = False


def touch_heartbeat() -> None:
    try:
        HEARTBEAT_PATH.parent.mkdir(parents=True, exist_ok=True)
        HEARTBEAT_PATH.touch()
    except Exception:
        pass


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def clamp01(value: float) -> float:
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=True) + "\n")
    except Exception:
        # Daemon must not stop because of transient logging failures.
        pass


def log_event(event_type: str, payload: dict[str, Any]) -> None:
    append_jsonl(
        EVENTS_PATH,
        {
            "timestamp": now_iso(),
            "event_type": event_type,
            "payload": payload,
        },
    )


def log_metrics(payload: dict[str, Any]) -> None:
    append_jsonl(
        METRICS_PATH,
        {
            "timestamp": now_iso(),
            "event_type": "metrics",
            "payload": payload,
        },
    )


def random_strategy() -> dict[str, float]:
    return {key: random.random() for key in STRATEGY_KEYS}


def normalize_strategy(value: Any) -> dict[str, float] | None:
    if not isinstance(value, dict):
        return None
    normalized: dict[str, float] = {}
    for key in STRATEGY_KEYS:
        raw = value.get(key)
        if raw is None:
            return None
        try:
            normalized[key] = clamp01(float(raw))
        except Exception:
            return None
    return normalized


def mutate_strategy(strategy: dict[str, float]) -> dict[str, float]:
    return {
        key: clamp01(val + random.uniform(-MUTATION_NOISE, MUTATION_NOISE))
        for key, val in strategy.items()
    }


def evaluate_strategy(strategy: dict[str, float]) -> float:
    return (
        strategy["quality"] * 0.3
        + strategy["novelty"] * 0.25
        + strategy["diversity"] * 0.2
        + strategy["efficiency"] * 0.15
        - strategy["cost"] * 0.1
    )


def load_domains() -> list[str]:
    domains: list[str] = []
    if not DOMAINS_DIR.exists():
        return domains

    for entry in sorted(DOMAINS_DIR.iterdir()):
        if not entry.is_file() or entry.suffix != ".py":
            continue
        if entry.stem.startswith("_") or entry.stem == "__init__":
            continue

        module_name = f"domains.{entry.stem}"
        try:
            module = importlib.import_module(module_name)
            if callable(getattr(module, "generate", None)):
                domains.append(entry.stem)
        except Exception as exc:
            log_event("domain_load_error", {"module": module_name, "error": str(exc)})

    return domains


def resolve_domain_generate(domain_name: str) -> Callable[[], Any] | None:
    cached = _DOMAIN_GENERATE_CACHE.get(domain_name)
    if cached is not None or domain_name in _DOMAIN_GENERATE_CACHE:
        return cached

    module_name = f"domains.{domain_name}"
    try:
        module = importlib.import_module(module_name)
        generator = getattr(module, "generate", None)
        if callable(generator):
            _DOMAIN_GENERATE_CACHE[domain_name] = generator
        else:
            _DOMAIN_GENERATE_CACHE[domain_name] = None
    except Exception:
        _DOMAIN_GENERATE_CACHE[domain_name] = None

    return _DOMAIN_GENERATE_CACHE[domain_name]


def resolve_llm_generator() -> Callable[[str, dict[str, Any]], Any] | None:
    global _LLM_GENERATOR
    global _LLM_RESOLVED

    if _LLM_RESOLVED:
        return _LLM_GENERATOR

    _LLM_RESOLVED = True
    try:
        module = importlib.import_module("core.llm_provider")
        llm_fn = getattr(module, "generate_llm_strategy", None)
        if callable(llm_fn):
            _LLM_GENERATOR = llm_fn
            log_event("llm_provider_enabled", {})
            return _LLM_GENERATOR
    except Exception:
        _LLM_GENERATOR = None

    return None


def create_artifact(strategy: dict[str, float], score: float, source: str, tick: int) -> str | None:
    try:
        ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
        artifact_id = str(uuid.uuid4())
        artifact_path = ARTIFACT_DIR / artifact_id
        artifact_path.mkdir(parents=True, exist_ok=True)

        payload = {
            "timestamp": now_iso(),
            "tick": tick,
            "source": source,
            "score": score,
            "strategy": strategy,
        }
        with (artifact_path / "artifact.json").open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=True)

        return artifact_id
    except Exception as exc:
        log_event("artifact_write_error", {"tick": tick, "error": str(exc)})
        return None


def artifact_count() -> int:
    try:
        if not ARTIFACT_DIR.exists():
            return 0
        return sum(1 for item in ARTIFACT_DIR.iterdir() if item.is_dir())
    except Exception:
        return 0


def cleanup_artifacts() -> int:
    try:
        ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
        items = [item for item in ARTIFACT_DIR.iterdir() if item.is_dir()]
        if len(items) <= ARTIFACT_LIMIT:
            return 0

        items.sort(key=lambda p: p.stat().st_mtime)
        to_remove = min(ARTIFACT_PURGE_COUNT, len(items))
        for path in items[:to_remove]:
            shutil.rmtree(path, ignore_errors=True)
        return to_remove
    except Exception as exc:
        log_event("artifact_cleanup_error", {"error": str(exc)})
        return 0


def rotate_log_if_needed(path: Path) -> str | None:
    try:
        if not path.exists() or path.stat().st_size <= LOG_ROTATE_BYTES:
            return None

        LOG_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        rotated_name = f"{path.stem}-{stamp}.jsonl"
        rotated_path = LOG_ARCHIVE_DIR / rotated_name
        os.replace(path, rotated_path)
        return str(rotated_path)
    except Exception as exc:
        log_event("log_rotate_error", {"path": str(path), "error": str(exc)})
        return None


def rotate_logs() -> None:
    rotated_metrics = rotate_log_if_needed(METRICS_PATH)
    if rotated_metrics:
        log_event("log_rotated", {"kind": "metrics", "path": rotated_metrics})

    rotated_events = rotate_log_if_needed(EVENTS_PATH)
    if rotated_events:
        append_jsonl(
            EVENTS_PATH,
            {
                "timestamp": now_iso(),
                "event_type": "log_rotated",
                "payload": {"kind": "events", "path": rotated_events},
            },
        )


def load_checkpoint() -> tuple[list[dict[str, float]], float, int]:
    default_population = [random_strategy() for _ in range(POPULATION_SIZE)]
    default_best = float("-inf")
    default_tick = 0

    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        if not CHECKPOINT_PATH.exists():
            return default_population, default_best, default_tick

        with CHECKPOINT_PATH.open("r", encoding="utf-8") as handle:
            raw = json.load(handle)

        population_raw = raw.get("population", [])
        population: list[dict[str, float]] = []
        if isinstance(population_raw, list):
            for item in population_raw:
                normalized = normalize_strategy(item)
                if normalized is not None:
                    population.append(normalized)

        if not population:
            population = default_population

        try:
            best_score = float(raw.get("best_score", default_best))
        except Exception:
            best_score = default_best

        try:
            tick = int(raw.get("tick", default_tick))
        except Exception:
            tick = default_tick

        return population[:POPULATION_SIZE], best_score, tick
    except Exception as exc:
        log_event("checkpoint_load_error", {"error": str(exc)})
        return default_population, default_best, default_tick


def save_checkpoint(population: list[dict[str, float]], best_score: float, tick: int) -> None:
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        payload = {
            "population": population[:POPULATION_SIZE],
            "best_score": best_score,
            "tick": tick,
            "timestamp": now_iso(),
        }

        temp_path = CHECKPOINT_PATH.with_suffix(".tmp")
        with temp_path.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=True)
        os.replace(temp_path, CHECKPOINT_PATH)
    except Exception as exc:
        log_event("checkpoint_save_error", {"tick": tick, "error": str(exc)})


def cpu_usage_percent() -> float:
    if psutil is not None:
        try:
            return float(psutil.cpu_percent(interval=0.0))
        except Exception:
            pass

    try:
        load1, _, _ = os.getloadavg()
        return clamp01(load1 / CPU_COUNT) * 100.0
    except Exception:
        return 50.0


def adapt_worker_count(current: int, cpu_percent: float) -> int:
    if cpu_percent > 80.0:
        reduced = int(current * 0.75)
        if reduced == current:
            reduced = current - 1
        return max(MIN_WORKERS, reduced)

    if cpu_percent < 50.0:
        increased = max(current + 1, int(current * 1.25))
        return min(MAX_WORKERS, increased)

    return current


def evolve_population(results: list[dict[str, Any]], target_size: int = POPULATION_SIZE) -> list[dict[str, float]]:
    if not results:
        return [random_strategy() for _ in range(target_size)]

    ordered = sorted(results, key=lambda item: float(item["score"]), reverse=True)
    elite_count = max(4, target_size // 4)
    elites = [item["strategy"] for item in ordered[:elite_count]]

    next_population = list(elites)
    while len(next_population) < target_size:
        parent = random.choice(elites)
        next_population.append(mutate_strategy(parent))

    return next_population[:target_size]


def worker(task: tuple[dict[str, float], list[str], int]) -> dict[str, Any]:
    base_strategy, domain_names, tick = task

    try:
        source = "random"
        domain_name = random.choice(domain_names) if domain_names else ""
        strategy: dict[str, float] | None = None

        llm_fn = resolve_llm_generator()
        if llm_fn is not None and domain_name:
            try:
                context = {"tick": tick, "domain": domain_name, "base_strategy": base_strategy, "quest": _CURRENT_QUEST}
                strategy = normalize_strategy(llm_fn(domain_name, context))
                if strategy is not None:
                    source = "llm"
            except Exception:
                strategy = None

        if strategy is None and domain_name:
            domain_generate = resolve_domain_generate(domain_name)
            if domain_generate is not None:
                try:
                    base_strategy = replay_sample()
                    if base_strategy is None:
                        base_strategy = domain_generate()
                    strategy = normalize_strategy(base_strategy)
                    if strategy is not None:
                        source = f"domain:{domain_name}"
                except Exception:
                    strategy = None

        if strategy is None:
            strategy = random_strategy()
            source = "random"

        blended = {
            key: clamp01((0.6 * strategy[key]) + (0.4 * base_strategy[key]))
            for key in STRATEGY_KEYS
        }
        candidate = mutate_strategy(blended)
        score = evaluate_strategy(candidate)

        return {
            "ok": True,
            "strategy": candidate,
            "score": score,
            "source": source,
            "domain": domain_name,
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def create_pool(worker_count: int) -> mp.pool.Pool:
    return mp.Pool(processes=worker_count, maxtasksperchild=POOL_TASKS_PER_CHILD)


def run_daemon() -> None:
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    LOG_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

    domains = load_domains()
    population, best_score, tick = load_checkpoint()

    worker_count = min(MAX_WORKERS, max(MIN_WORKERS, INITIAL_WORKERS))
    pool = create_pool(worker_count)

    log_event(
        "autonomous_daemon_start",
        {
            "worker_count": worker_count,
            "domain_count": len(domains),
            "domains": domains,
            "tick": tick,
        },
    )

    try:
        while True:
            try:
                tick += 1

                # QUEST: direction control
                quest, quest_changed = ensure_quest(tick, domain_hint=None)
                quest = update_quest(quest, tick, best_score=best_score)
                global _CURRENT_QUEST
                _CURRENT_QUEST = quest
                if quest_changed:
                    log_event('quest_changed', {'tick': tick, 'quest': quest})


                tasks = [
                    (random.choice(population), domains, tick)
                    for _ in range(worker_count)
                ]

                try:
                    batch = pool.map(worker, tasks)
                except Exception as exc:
                    log_event("pool_map_error", {"tick": tick, "error": str(exc)})
                    pool.terminate()
                    pool.join()
                    pool = create_pool(worker_count)
                    batch = []

                successful: list[dict[str, Any]] = []
                for item in batch:
                    if item.get("ok"):
                        successful.append(item)
                    else:
                        log_event("worker_error", {"tick": tick, "error": str(item.get("error", "unknown"))})

                if not successful:
                    fallback = random_strategy()
                    successful = [{"strategy": fallback, "score": evaluate_strategy(fallback), "source": "fallback", "domain": ""}]

                for result in successful:
                    strategy = result["strategy"]
                    score = float(result["score"])
                    source = str(result.get("source", "unknown"))

                    artifact_id = create_artifact(strategy, score, source, tick)
                    log_metrics(
                        {
                            "tick": tick,
                            "score": score,
                            "source": source,
                            "domain": result.get("domain", ""),
                            **strategy,
                        }
                    )
                    log_event(
                        "artifact_created",
                        {
                            "tick": tick,
                            "artifact_id": artifact_id or "",
                            "score": score,
                            "source": source,
                        },
                    )

                batch_best = max(float(x["score"]) for x in successful)
                if batch_best > best_score:
                    best_score = batch_best
                    log_event("new_best_score", {"tick": tick, "best_score": best_score})

                population = evolve_population(successful, POPULATION_SIZE)
                save_checkpoint(population, best_score, tick)

                removed = cleanup_artifacts()
                if removed > 0:
                    log_event("artifacts_pruned", {"tick": tick, "removed": removed})

                rotate_logs()

                cpu = cpu_usage_percent()
                next_workers = adapt_worker_count(worker_count, cpu)
                if next_workers != worker_count:
                    previous = worker_count
                    pool.close()
                    pool.join()
                    worker_count = next_workers
                    pool = create_pool(worker_count)
                    log_event(
                        "workers_scaled",
                        {
                            "tick": tick,
                            "cpu_percent": cpu,
                            "from": previous,
                            "to": worker_count,
                        },
                    )

                artifacts = artifact_count()
                print(
                    f"tick={tick} score={batch_best:.4f} workers={worker_count} artifacts={artifacts}",
                    flush=True,
                )

                time.sleep(TICK_SLEEP_SECONDS)
            except Exception as exc:
                log_event("daemon_tick_error", {"tick": tick, "error": str(exc)})
                time.sleep(1.0)
    except KeyboardInterrupt:
        log_event("autonomous_daemon_stop", {"tick": tick, "reason": "keyboard_interrupt"})
    finally:
        try:
            pool.terminate()
            pool.join()
        except Exception:
            pass


if __name__ == "__main__":
    run_daemon()
