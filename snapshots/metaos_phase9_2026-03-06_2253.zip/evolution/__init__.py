"""Civilization MVP evolution helpers."""
