"""METAOS Civilization MVP package."""
